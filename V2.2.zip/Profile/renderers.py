from Utils.renderers import UtilJSONRenderer

class ProfileJSONRenderer(UtilJSONRenderer):
    object_label = 'profile'
